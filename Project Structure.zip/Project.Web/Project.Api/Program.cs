using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Project.Data.Context;
using WEB.StartupExtentions;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
builder.Services.ConfiguringRepositories();
builder.Services.ConfiguringServices();
builder.Services.ConfiguringGlobalServices(builder.Configuration);
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

//builder.Services.AddDbContext<testcontext>(option =>
//{
//    //option.UseSqlServer(builder.Configuration.GetConnectionString("SqlConnection"));
//    option.UseSqlServer(builder.Configuration.GetValue<string>("ConnectionStrings:SqlConnection").ToString());
    
//});


var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
