using InstantAPIs;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Project.Data.Context;
using System.Configuration;
using WEB.StartupExtentions;

var builder = WebApplication.CreateBuilder(args);

// Add configuration to the app
//builder.Configuration.AddJsonFile("appsettings.json");



builder.Services.AddControllers();

// Add services to the container.
builder.Services.ConfiguringRepositories();
builder.Services.ConfiguringServices();
builder.Services.ConfiguringGlobalServices(builder.Configuration);

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

//app.MapInstantAPIs<testcontext>();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
