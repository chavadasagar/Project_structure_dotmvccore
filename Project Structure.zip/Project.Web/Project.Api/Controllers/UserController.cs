﻿using log4net;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Project.Common.Models;
using Project.Data.Context;
using Project.Service.IService;

// CREATE USING DAPPER
namespace Project.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _user;
        private static readonly ILog log = LogManager.GetLogger(typeof(UserController));


        public UserController(IUserService user,testcontext context)
        {
            _user = user;
        }

        [HttpGet]
        public async Task<List<User>> getallusers()
        {
            try
            {
                log.Info("working fine in api");

                var user = await _user.GetAllUser();
                return user;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
