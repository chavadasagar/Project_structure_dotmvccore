﻿using log4net;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Project.Common.Models;
using Project.Data.Context;
using Project.Data.UoW;
using Project.Service.IService;

// CREATE USING DAPPER
namespace Project.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userservice;
        private readonly IGenericRepository<User> _user;
        private static readonly ILog log = LogManager.GetLogger(typeof(UserController));

        public UserController(IUserService userservice, testcontext context, IGenericRepository<User> user)
        {
            _userservice = userservice;
            _user = user;
        }

        [HttpGet]
        public async Task<List<User>> GetAllUsersUsingSp()
        {
            try
            {
                // IT IS CREATE USING STORED PROCEDURE
                var user = await _userservice.GetAllUser();
                return user;
            }
            catch (Exception e)
            {
                log.Error(e.StackTrace);
                throw e;
            }

        }
        [HttpGet]
        public List<User> GetAllUsers()
        {
            try
            {
                return _user.GetAll().ToList();
            }
            catch (Exception e)
            {
                log.Error(e.StackTrace);
                throw e;
            }
        }


        [HttpPost]
        public ActionResult<User> AddUser(User user) {
            try
            {
                _user.Insert(user);
                _user.Save();
                return Ok(user);
            }
            catch (Exception e)
            {
                log.Error(e.StackTrace);
                throw e;
            }
        }
    }
}
