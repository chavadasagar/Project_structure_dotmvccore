﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Project.Common.Models;
using Project.Data.Context;
using Project.Service.IService;

namespace Project.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _user;
        private readonly testcontext _context;

        public UserController(IUserService user,testcontext context)
        {
            _user = user;
            _context = context;
        }

        [HttpGet]
        public async Task<List<User>> getallusers()
        {
            try
            {
                var user = await _user.GetAllUser();
                return user;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
