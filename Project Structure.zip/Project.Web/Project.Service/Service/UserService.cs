﻿using Project.Common.Models;
using Project.Data.IRepository;
using Project.Service.IService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Service.Service
{
    public class UserService:IUserService
    {
        private readonly IUserRepository _user;

        public UserService(IUserRepository user)
        {
            _user = user;
        }

        public async Task<List<User>> GetAllUser()
        {
            try
            {
                var Users = await _user.GetAllUser();
                return Users;
            }
            catch (Exception e)
            {
                throw;
            }
        }
    }
}
