﻿using Microsoft.EntityFrameworkCore;
using Project.Common.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Data.Context
{
    public class testcontext : DbContext
    {
        public testcontext()
        {

        }

        public testcontext(DbContextOptions<testcontext> options) : base(options)
        {
        }

        public DbSet<User> User { get; set; }

    }
}
