﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Project.Common.Models;
using Project.Service.IService;

namespace Project.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _user;

        public UserController(IUserService user)
        {
            _user = user;
        }

        [HttpGet]
        public async Task<List<User>> getallusers()
        {
            try
            {
                var user = await _user.GetAllUser();
                return user;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
