﻿using log4net;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Project.Common.Models;
using Project.Data.Context;
using Project.Data.UoW;
using Project.Service.IService;

// CREATE USING DAPPER
namespace Project.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userservice;
        private readonly IUnitOfWork _unitOfWork;
        private static readonly ILog log = LogManager.GetLogger(typeof(UserController));

        public UserController(IUserService userservice, testcontext context, IUnitOfWork unitOfWork)
        {
            _userservice = userservice;
            _unitOfWork = unitOfWork;
        }

        [HttpGet("GetAllUsersUsingUnitOfWork")]
        public async Task<List<User>> GetAllUsersUsingUnitOfWork()
        {
            try
            {
                var user = _unitOfWork.Repository<User>();
                return user.GetAll().ToList();
            }
            catch (Exception e)
            {
                log.Error(e);
                throw e;
            }
        }
        [HttpGet("GetAllUsersUsingSp")]
        public async Task<List<User>> GetAllUsersUsingSp()
        {
            try
            {
                // IT IS CREATE USING STORED PROCEDURE
                var user = await _userservice.GetAllUser();
                return user;
            }
            catch (Exception e)
            {
                log.Error(e.StackTrace);
                throw e;
            }

        }

        [HttpPost]
        public ActionResult<User> AddUser(User user) {
            try
            {
                var userrepo = _unitOfWork.Repository<User>();
                userrepo.Insert(user);
                userrepo.Save();
                return Ok(user);
            }
            catch (Exception e)
            {
                log.Error(e.StackTrace);
                throw e;
            }
        }
    }
}
