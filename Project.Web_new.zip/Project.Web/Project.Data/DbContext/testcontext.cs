﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Project.Common.Models;
using Project.Data.DapperConnection;
using Project.Domain.Models;

namespace Project.Data.Context
{
    public class testcontext : DbContext
    {
        private readonly IConfiguration _configuration;
        public testcontext()
        {
        }
        public testcontext(DbContextOptions<testcontext> options,IConfiguration config) : base(options)
        {
            _configuration = config;
        }
        public DbSet<User> User { get; set; }
        public DbSet<Todo> Todo { get; set; }
        public DbSet<Error> Error { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(_configuration.GetConnectionString("SqlConnection"));
            base.OnConfiguring(optionsBuilder);
        }
    }
}
